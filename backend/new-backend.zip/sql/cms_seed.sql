-- Seed CMS Data

USE yeha_tours;

-- Insert default site settings
INSERT INTO site_settings (setting_key, setting_value, setting_type, category, description) VALUES
('site_name', 'YEHA Niagara Falls Tours', 'text', 'general', 'Website name'),
('site_tagline', 'Experience the Majesty of Niagara Falls', 'text', 'general', 'Main tagline'),
('contact_email', 'info@yehatours.com', 'text', 'contact', 'Contact email'),
('contact_phone', '+1 (555) 123-4567', 'text', 'contact', 'Contact phone'),
('contact_address', 'Niagara Falls, ON, Canada', 'text', 'contact', 'Business address'),
('facebook_url', '#', 'text', 'social', 'Facebook URL'),
('instagram_url', '#', 'text', 'social', 'Instagram URL'),
('twitter_url', '#', 'text', 'social', 'Twitter URL'),
('enable_booking', 'true', 'boolean', 'features', 'Enable booking functionality'),
('enable_testimonials', 'true', 'boolean', 'features', 'Enable testimonials section'),
('enable_gallery', 'true', 'boolean', 'features', 'Enable gallery section'),
('maintenance_mode', 'false', 'boolean', 'general', 'Maintenance mode');

-- Insert default theme colors
INSERT INTO theme_colors (color_name, color_value, color_category) VALUES
('primary', '#06b6d4', 'primary'),
('primary-dark', '#0891b2', 'primary'),
('accent', '#f97316', 'accent'),
('accent-dark', '#ea580c', 'accent'),
('purple', '#a855f7', 'secondary'),
('purple-dark', '#9333ea', 'secondary'),
('ocean', '#14b8a6', 'secondary'),
('ocean-dark', '#0d9488', 'secondary'),
('emerald', '#10b981', 'secondary'),
('gold', '#f59e0b', 'accent'),
('background-light', '#ffffff', 'background'),
('background-dark', '#0f172a', 'background'),
('text-light', '#1f2937', 'text'),
('text-dark', '#f1f5f9', 'text');

-- Insert default site content
INSERT INTO site_content (content_key, content_value, content_type, section, page) VALUES
('hero_title', 'Experience the Majesty of Niagara Falls', 'text', 'hero', 'home'),
('hero_subtitle', 'Small group and private tours designed for unforgettable memories', 'text', 'hero', 'home'),
('hero_primary_button', 'Book Now', 'text', 'hero', 'home'),
('hero_secondary_button', 'View Tours', 'text', 'hero', 'home'),
('about_title', 'About YEHA Tours', 'text', 'about', 'home'),
('about_subtitle', 'We specialize in creating unforgettable experiences at Niagara Falls through small group and private tours designed for those who seek more than just a visit.', 'text', 'about', 'home'),
('about_story', 'At YEHA Niagara Falls Tours, we believe that every visit to this natural wonder should be extraordinary. Our expert guide Kaleb brings years of experience and passion to every tour, ensuring you don\'t just see the falls—you experience them.', 'text', 'about', 'home'),
('tours_title', 'Our Tour Packages', 'text', 'tours', 'home'),
('tours_subtitle', 'Choose the perfect tour experience for your Niagara Falls adventure', 'text', 'tours', 'home'),
('testimonials_title', 'What Our Guests Say', 'text', 'testimonials', 'home'),
('testimonials_subtitle', 'Don\'t just take our word for it—hear from travelers who\'ve experienced the magic', 'text', 'testimonials', 'home'),
('gallery_title', 'Our Gallery', 'text', 'gallery', 'home'),
('gallery_subtitle', 'Capturing the beauty and excitement of every tour experience', 'text', 'gallery', 'home'),
('contact_title', 'Get In Touch', 'text', 'contact', 'home'),
('contact_subtitle', 'Have questions? We\'d love to hear from you. Send us a message and we\'ll respond as soon as possible.', 'text', 'contact', 'home'),
('footer_description', 'Premium small group and private tours of Niagara Falls. Experience the majesty with expert guide Kaleb.', 'text', 'footer', 'global');

-- Insert default hero settings
INSERT INTO hero_settings (title, subtitle, description, primary_button_text, primary_button_link, secondary_button_text, secondary_button_link) VALUES
('Experience the Majesty of Niagara Falls', 'Small group and private tours designed for unforgettable memories', '', 'Book Now', '/book', 'View Tours', '/tours');

-- Insert section visibility
INSERT INTO section_visibility (section_key, section_name, visible, order_index) VALUES
('hero', 'Hero Section', TRUE, 1),
('about', 'About Section', TRUE, 2),
('tours', 'Tours Section', TRUE, 3),
('testimonials', 'Testimonials Section', TRUE, 4),
('gallery', 'Gallery Section', TRUE, 5),
('contact', 'Contact Section', TRUE, 6);

-- Insert default navigation menu
INSERT INTO navigation_menu (label, href, icon, order_index, visible) VALUES
('Home', '/', 'Home', 1, TRUE),
('Tours', '/tours', 'MapPin', 2, TRUE),
('About', '/about', 'Info', 3, TRUE),
('Reviews', '/testimonials', 'Star', 4, TRUE),
('Contact', '/contact', 'Mail', 5, TRUE);

-- Insert default site features
INSERT INTO site_features (feature_key, feature_name, enabled, description) VALUES
('dark_mode', 'Dark Mode', TRUE, 'Enable dark mode toggle'),
('animations', 'Animations', TRUE, 'Enable page animations'),
('parallax', 'Parallax Scrolling', TRUE, 'Enable parallax effects'),
('3d_effects', '3D Effects', TRUE, 'Enable 3D card effects'),
('video_background', 'Video Background', TRUE, 'Enable video background in hero'),
('sticky_cta', 'Sticky CTA Button', TRUE, 'Show floating book button'),
('social_sharing', 'Social Sharing', TRUE, 'Enable social media sharing'),
('live_chat', 'Live Chat', FALSE, 'Enable live chat widget'),
('newsletter', 'Newsletter Signup', FALSE, 'Enable newsletter subscription');

