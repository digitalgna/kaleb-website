-- Seed Data for YEHA Niagara Falls Tours

USE yeha_tours;

-- Insert Default Admin (password: admin123)
-- Note: This hash is for 'admin123'. Run generateAdminHash.js to generate a new one if needed.
-- If admin already exists, use: node sql/createAdmin.js to update the password
INSERT INTO admins (username, password_hash, email, role) VALUES
('admin', '$2a$10$uYndeqoYUqU5i6xq0E9zwOwNqInP3N9dxZMh6Yb.gUZq98IjxsHYy', 'admin@yehatours.com', 'super_admin')
ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash);

-- Insert Tours
INSERT INTO tours (title, slug, description, short_description, price, duration, group_size, images, highlights) VALUES
(
    'Ultra Small Niagara Tour',
    'ultra-small-niagara-tour',
    'Experience the breathtaking beauty of Niagara Falls in an intimate small group setting. This premium tour offers personalized attention from our expert guide Kaleb, ensuring you capture every moment of this natural wonder. Perfect for couples, families, and solo travelers seeking a more personal experience.',
    'Intimate small group tour with expert guide Kaleb. Personalized attention and unforgettable memories.',
    150.00,
    '4-5 hours',
    '2-6 guests',
    '["/images/tours/ultra-small-1.jpg", "/images/tours/ultra-small-2.jpg", "/images/tours/ultra-small-3.jpg"]',
    '["Expert guide Kaleb", "Small group (2-6 guests)", "Luxury comfort vehicle", "Personalized commentary", "Photo opportunities"]'
),
(
    'Private Premium Tour',
    'private-premium-tour',
    'The ultimate luxury experience at Niagara Falls. This exclusive private tour is designed for those who demand the finest. Enjoy complete flexibility, premium comfort, and undivided attention from our expert guide. Customize your itinerary to include helicopter rides, boat tours, or extended exploration.',
    'Ultimate luxury private tour with complete flexibility and premium comfort.',
    750.00,
    '6-8 hours',
    'Private (1-8 guests)',
    '["/images/tours/private-1.jpg", "/images/tours/private-2.jpg", "/images/tours/private-3.jpg"]',
    '["Fully private experience", "Luxury vehicle", "Customizable itinerary", "Premium add-ons available", "Expert guide"]'
),
(
    'Small Group Day Tour',
    'small-group-day-tour',
    'Join a small group of fellow travelers for an energetic and comprehensive day tour of Niagara Falls. This tour combines the best of both worlds: the camaraderie of group travel with the intimacy of small groups. Air-conditioned comfort, multiple stops, and expert commentary throughout.',
    'Energetic small group day tour with multiple stops and expert commentary.',
    150.00,
    '5-6 hours',
    '4-8 guests',
    '["/images/tours/group-1.jpg", "/images/tours/group-2.jpg", "/images/tours/group-3.jpg"]',
    '["Small group (4-8 guests)", "AC vehicle", "Multiple stops", "Expert guide", "Group camaraderie"]'
);

-- Insert Itinerary for Ultra Small Tour
INSERT INTO itinerary (tour_id, step_number, step_title, step_text) VALUES
(1, 1, 'Hotel Pickup', 'Convenient pickup from your hotel or preferred location in Niagara area'),
(1, 2, 'Niagara Falls Overview', 'Introduction to the falls with expert commentary from guide Kaleb'),
(1, 3, 'Maid of the Mist Experience', 'Optional boat ride to the base of the falls (add-on available)'),
(1, 4, 'Scenic Viewpoints', 'Visit multiple viewpoints for the best photo opportunities'),
(1, 5, 'Local Insights', 'Learn about the history, geology, and local stories of Niagara Falls'),
(1, 6, 'Return Drop-off', 'Comfortable return to your hotel or preferred location');

-- Insert Itinerary for Private Premium Tour
INSERT INTO itinerary (tour_id, step_number, step_title, step_text) VALUES
(2, 1, 'Luxury Pickup', 'Premium vehicle pickup from your location'),
(2, 2, 'Customized Itinerary', 'Work with your guide to customize your perfect day'),
(2, 3, 'Exclusive Access', 'Access to premium viewing areas and experiences'),
(2, 4, 'Helicopter Tour', 'Optional helicopter ride over the falls (add-on)'),
(2, 5, 'Fine Dining', 'Lunch at premium restaurant with falls view (optional)'),
(2, 6, 'Extended Exploration', 'Extended time at each location, no rush'),
(2, 7, 'Premium Return', 'Luxury return with refreshments');

-- Insert Itinerary for Small Group Day Tour
INSERT INTO itinerary (tour_id, step_number, step_title, step_text) VALUES
(3, 1, 'Group Meeting Point', 'Meet at designated location with your small group'),
(3, 2, 'Falls Introduction', 'Group introduction and safety briefing'),
(3, 3, 'Multiple Viewpoints', 'Visit 5-6 different viewpoints for varied perspectives'),
(3, 4, 'Interactive Experience', 'Engage with interactive exhibits and displays'),
(3, 5, 'Group Photo Session', 'Professional group photos at iconic locations'),
(3, 6, 'Local Culture', 'Learn about local culture and history'),
(3, 7, 'Return Journey', 'Comfortable return with new friends');

-- Insert Tour Add-ons
INSERT INTO tour_addons (tour_id, name, description, price) VALUES
(1, 'Maid of the Mist Boat Ride', 'Experience the power of the falls from the base', 25.00),
(1, 'Helicopter Tour', 'Aerial view of Niagara Falls', 150.00),
(2, 'Helicopter Tour', 'Premium aerial experience', 150.00),
(2, 'Fine Dining Experience', 'Lunch at premium restaurant', 75.00),
(2, 'Extended Tour', 'Add 2 hours to your tour', 200.00),
(3, 'Maid of the Mist', 'Group boat ride experience', 25.00);

-- Insert Testimonials
INSERT INTO testimonials (name, rating, comment, location, approved) VALUES
('Sarah Johnson', 5, 'Absolutely incredible experience! Kaleb was an amazing guide who made our tour unforgettable. The small group size meant we got personalized attention and could ask all our questions. Highly recommend!', 'Toronto, Canada', TRUE),
('Michael Chen', 5, 'The private premium tour was worth every penny. Complete flexibility, luxury vehicle, and Kaleb knew all the best spots. The helicopter add-on was breathtaking!', 'New York, USA', TRUE),
('Emma Williams', 5, 'Perfect day tour! Small group was great for meeting people, and the guide was knowledgeable and friendly. The AC vehicle was a lifesaver in the heat.', 'London, UK', TRUE),
('David Rodriguez', 5, 'Best tour we\'ve ever taken. Kaleb\'s commentary was engaging, and the small group size made it feel like a private tour. The photo opportunities were amazing!', 'Los Angeles, USA', TRUE),
('Lisa Anderson', 5, 'Exceeded all expectations! The tour was well-organized, comfortable, and informative. Kaleb is a true professional. We\'ll definitely book again!', 'Chicago, USA', TRUE),
('James Thompson', 5, 'Outstanding service from start to finish. The booking process was easy, and the tour itself was spectacular. The small group format is perfect!', 'Vancouver, Canada', TRUE);

